const STORAGE_KEY = 'studyroom-data-v1';
const FEATURE_INFO = {
  voice: { eyebrow: 'A TEACHER WHO LISTENS', title: 'Let’s talk it through.', intro: 'Say what’s on your mind. Your teacher will listen, help you untangle it, and can talk the answer back.' },
  doubt: { eyebrow: 'NO QUESTION TOO SMALL', title: 'Let’s solve this together.', intro: 'Upload a clear photo of the question. We’ll take it one step at a time.' },
  diagram: { eyebrow: 'SEE THE BIG PICTURE', title: 'Let’s make it make sense.', intro: 'Share a diagram, chart, or flowchart and get a friendly, step-by-step explanation.' },
  code: { eyebrow: 'LEARN BY UNDERSTANDING', title: 'Let’s read this code.', intro: 'Paste your code and your teacher will explain how it works, not just what to change.' },
  weakness: { eyebrow: 'A KINDER WAY TO GET BETTER', title: 'Find your next focus.', intro: 'Share what feels hard or use your recent study activity to spot where a little practice could help.' },
  revision: { eyebrow: 'A PLAN THAT FITS REAL LIFE', title: 'Make revision feel doable.', intro: 'Tell us when your exam is and how much time you have. We’ll build a plan around you.' },
  exam: { eyebrow: 'A CHECK-IN, NOT A JUDGMENT', title: 'How ready are you feeling?', intro: 'Share your mock test results for a grounded estimate and a few practical next steps.' }
};

const state = {
  user: null,
  data: { sessions: [], mocks: [], subjects: [] },
  activeFeature: null,
  mediaRecorder: null,
  recordedChunks: [],
  recording: false,
  toastTimer: null
};

const $ = (selector, root = document) => root.querySelector(selector);
const authScreen = $('#auth-screen');
const appShell = $('#app-shell');
const modal = $('#feature-modal');
const modalContent = $('#modal-content');

function showToast(message, isError = false) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.toggle('error', isError);
  toast.classList.add('visible');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.remove('visible'), 4200);
}

function getErrorMessage(error) {
  if (error && typeof error.msg === 'string') return error.msg;
  if (error && typeof error.message === 'string') return error.message;
  return 'Something went wrong. Please try again.';
}

function extractText(response) {
  if (typeof response === 'string') return response;
  const content = response && response.message && response.message.content;
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content.map((part) => typeof part === 'string' ? part : (part.text || '')).filter(Boolean).join('\n');
  }
  if (response && typeof response.text === 'string') return response.text;
  return 'Your teacher couldn’t find a text response. Please try again.';
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
}

function featureFormMarkup(feature) {
  if (feature === 'voice') {
    return `<div class="record-panel"><button id="record-button" class="record-button" type="button" aria-label="Start recording">●</button><span id="record-caption" class="record-caption">Tap to start talking</span></div><label class="field-label transcript-field">Or type your question<textarea id="voice-question" placeholder="What are you wondering about?"></textarea></label><button class="button button-dark form-submit" type="submit">Ask your teacher <span>↗</span></button>`;
  }
  if (feature === 'doubt' || feature === 'diagram') {
    const prompt = feature === 'doubt' ? 'Any extra context? (optional)' : 'What would you especially like to understand? (optional)';
    return `<label class="field-label">Upload an image <input id="feature-image" class="file-input" type="file" accept="image/*" required><span class="field-hint">PNG, JPG, or another image format</span></label><div id="image-preview-wrap"></div><label class="field-label">${prompt}<textarea id="feature-context" placeholder="Add a note for your teacher"></textarea></label><button class="button button-dark form-submit" type="submit">${feature === 'doubt' ? 'Solve this question' : 'Explain this diagram'} <span>↗</span></button>`;
  }
  if (feature === 'code') {
    return `<label class="field-label">Programming language <select id="code-language"><option>JavaScript</option><option>Python</option><option>Java</option><option>C++</option><option>TypeScript</option><option>Other / not sure</option></select></label><label class="field-label">Your code<textarea id="code-input" required placeholder="Paste your code here…" spellcheck="false"></textarea></label><label class="field-label">What feels confusing? <input id="code-context" placeholder="Optional — e.g. the loop or this error"></label><button class="button button-dark form-submit" type="submit">Explain my code <span>↗</span></button>`;
  }
  if (feature === 'weakness') {
    return `<label class="field-label">Subject or topics <input id="weakness-subject" placeholder="e.g. Biology — genetics, cell division"></label><label class="field-label">What have you found difficult? <textarea id="weakness-context" placeholder="Share recent quiz results, topics that feel fuzzy, or leave this blank to use your study history"></textarea></label><button class="button button-dark form-submit" type="submit">Find my focus <span>↗</span></button>`;
  }
  if (feature === 'revision') {
    return `<label class="field-label">What are you revising? <input id="revision-subject" required placeholder="e.g. Year 11 chemistry"></label><div class="form-two-col"><label class="field-label">Exam date <input id="revision-date" type="date" required></label><label class="field-label">Minutes per day <input id="revision-minutes" type="number" min="10" max="480" value="45" required></label></div><label class="field-label">Topics to cover <textarea id="revision-topics" placeholder="List topics, strongest/weakest areas, or priorities"></textarea></label><button class="button button-dark form-submit" type="submit">Build my plan <span>↗</span></button>`;
  }
  return `<label class="field-label">Subject or exam <input id="exam-subject" required placeholder="e.g. Biology final"></label><label class="field-label">Mock test scores <textarea id="exam-scores" required placeholder="e.g. 68% on cell biology (Oct 3), 74% on genetics (Oct 20)"></textarea><span class="field-hint">Add your scores, dates, and topics if you have them.</span></label><label class="field-label">Exam date <input id="exam-date" type="date"></label><button class="button button-dark form-submit" type="submit">Estimate my readiness <span>↗</span></button>`;
}

function openFeature(feature) {
  state.activeFeature = feature;
  const info = FEATURE_INFO[feature];
  modalContent.innerHTML = `<span class="modal-eyebrow">${info.eyebrow}</span><h2 id="modal-title">${info.title}</h2><p class="modal-intro">${info.intro}</p><form id="feature-form" class="feature-form">${featureFormMarkup(feature)}<div id="feature-result" aria-live="polite"></div></form>`;
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
  $('#modal-close').focus();
  $('#feature-form').addEventListener('submit', onFeatureSubmit);
  if (feature === 'voice') $('#record-button').addEventListener('click', toggleRecording);
  if (feature === 'doubt' || feature === 'diagram') $('#feature-image').addEventListener('change', previewImage);
}

function closeFeature() {
  if (state.recording && state.mediaRecorder) state.mediaRecorder.stop();
  modal.hidden = true;
  document.body.style.overflow = '';
  modalContent.replaceChildren();
  state.activeFeature = null;
}

function previewImage(event) {
  const file = event.target.files && event.target.files[0];
  const wrapper = $('#image-preview-wrap');
  wrapper.replaceChildren();
  if (!file) return;
  if (!file.type.startsWith('image/')) {
    event.target.value = '';
    showToast('Please choose an image file.', true);
    return;
  }
  const image = document.createElement('img');
  image.className = 'image-preview';
  image.alt = 'Selected question or diagram';
  image.src = URL.createObjectURL(file);
  wrapper.append(image);
}

function setBusy(form, busy, label = 'Your teacher is thinking…') {
  const button = $('.form-submit', form);
  if (!button) return;
  if (busy) {
    button.dataset.originalText = button.textContent;
    button.disabled = true;
    button.innerHTML = `<span class="loading-label"><i class="spinner"></i>${escapeHtml(label)}</span>`;
  } else {
    button.disabled = false;
    button.textContent = button.dataset.originalText || 'Try again';
  }
}

function showResult(text, audio = null) {
  const result = $('#feature-result');
  result.replaceChildren();
  const panel = document.createElement('div');
  panel.className = 'result-panel';
  const heading = document.createElement('div');
  heading.className = 'result-heading';
  heading.textContent = 'A note from your teacher';
  const answer = document.createElement('p');
  answer.className = 'result-text';
  answer.textContent = text;
  panel.append(heading, answer);
  if (audio) {
    audio.className = 'result-audio';
    audio.controls = true;
    panel.append(audio);
  }
  result.append(panel);
  panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

async function askTeacher(prompt, options = {}) {
  const response = options.file
    ? await puter.ai.chat(prompt, options.file)
    : await puter.ai.chat(prompt, { model: 'gpt-5.4-nano' });
  return extractText(response);
}

function buildPrompt(feature, values) {
  const voice = 'You are a warm, patient personal teacher. Explain clearly in an encouraging tone, ask a clarifying question if needed, and keep the answer practical. The student asks: ';
  if (feature === 'voice') return `${voice}${values.question}`;
  if (feature === 'doubt') return `You are a patient tutor. Read and solve the student's question in the attached image. Explain the reasoning step by step, define tricky terms, then give a quick check-for-understanding question. Extra context: ${values.context || 'none'}.`;
  if (feature === 'diagram') return `You are a clear visual-thinking teacher. Explain the diagram or flowchart in the attached image: identify its main idea, walk through the parts and connections in order, and clarify any labels. Focus requested by student: ${values.context || 'give an overall explanation'}.`;
  if (feature === 'code') return `You are a friendly ${values.language} programming tutor. Explain this code in plain language, then walk through important sections and mention any bugs or improvements gently. The student's confusion: ${values.context || 'explain the code overall'}. Code:\n${values.code}`;
  if (feature === 'weakness') return `You are an encouraging learning coach. Based on this student's self-reported data, identify likely weak topics (be clear that this is an estimate, not a diagnosis), explain the evidence, and suggest 3 short focused practice steps. Do not invent scores. Subject/topics: ${values.subject || 'not specified'}. Student notes: ${values.context || 'No notes; use the available study history below.'}. Study history: ${values.history || 'No prior sessions recorded.'}`;
  if (feature === 'revision') return `You are a realistic study planner. Create a day-by-day revision plan with manageable sessions for the period ending ${values.date}, starting today. Subject: ${values.subject}. Available study time: ${values.minutes} minutes per day. Topics and priorities: ${values.topics || 'Please propose a balanced review sequence and include practice and rest days.'}. Format as dated or numbered days with topic, short activity, and a simple check-off target. Keep it encouraging and practical; never claim reminders were scheduled.`;
  return `You are an honest, supportive exam preparation coach. Based on these mock test results, estimate current preparation level as a broad range or qualitative category, explain uncertainty and the evidence, and offer three high-value next steps. This is not a guaranteed exam score. Do not imply certainty or invent data. Subject: ${values.subject}. Mock test scores: ${values.scores}. Exam date: ${values.date || 'not provided'}.`;
}

async function onFeatureSubmit(event) {
  event.preventDefault();
  const feature = state.activeFeature;
  const form = event.currentTarget;
  let values = {};
  let file = null;
  if (feature === 'voice') {
    values.question = $('#voice-question').value.trim();
    if (!values.question) {
      showToast('Say or type a question first.', true);
      return;
    }
  } else if (feature === 'doubt' || feature === 'diagram') {
    file = $('#feature-image').files[0];
    if (!file) return;
    values.context = $('#feature-context').value.trim();
  } else if (feature === 'code') {
    values.language = $('#code-language').value;
    values.code = $('#code-input').value.trim();
    values.context = $('#code-context').value.trim();
    if (!values.code) return;
  } else if (feature === 'weakness') {
    values.subject = $('#weakness-subject').value.trim();
    values.context = $('#weakness-context').value.trim();
    values.history = state.data.sessions.slice(0, 12).map((item) => `${item.feature}: ${item.topic}`).join('; ');
  } else if (feature === 'revision') {
    values.subject = $('#revision-subject').value.trim();
    values.date = $('#revision-date').value;
    values.minutes = $('#revision-minutes').value;
    values.topics = $('#revision-topics').value.trim();
  } else {
    values.subject = $('#exam-subject').value.trim();
    values.scores = $('#exam-scores').value.trim();
    values.date = $('#exam-date').value;
  }

  setBusy(form, true);
  try {
    const answer = await askTeacher(buildPrompt(feature, values), { file });
    const audio = feature === 'voice' ? await puter.ai.txt2speech(answer.slice(0, 3000)) : null;
    showResult(answer, audio);
    try {
      await recordSession(feature, values.subject || values.language || values.question || feature);
      if (feature === 'exam') await recordMock(values.subject, values.scores);
      refreshProgress();
    } catch (error) {
      showToast(`Your answer is ready, but progress couldn't be saved: ${getErrorMessage(error)}`, true);
    }
  } catch (error) {
    showToast(`Your teacher couldn't finish that: ${getErrorMessage(error)}`, true);
  } finally {
    setBusy(form, false);
  }
}

async function toggleRecording() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) {
    showToast('Voice recording is not supported in this browser. You can type your question instead.', true);
    return;
  }
  if (state.recording && state.mediaRecorder) {
    state.mediaRecorder.stop();
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    state.recordedChunks = [];
    state.mediaRecorder = new MediaRecorder(stream);
    state.mediaRecorder.addEventListener('dataavailable', (event) => {
      if (event.data.size) state.recordedChunks.push(event.data);
    });
    state.mediaRecorder.addEventListener('stop', async () => {
      stream.getTracks().forEach((track) => track.stop());
      state.recording = false;
      const button = $('#record-button');
      const caption = $('#record-caption');
      if (button) button.classList.remove('recording');
      if (caption) caption.textContent = 'Transcribing your question…';
      try {
        const audio = new Blob(state.recordedChunks, { type: state.mediaRecorder.mimeType || 'audio/webm' });
        const transcript = await puter.ai.speech2txt(audio, { response_format: 'text' });
        if ($('#voice-question')) $('#voice-question').value = typeof transcript === 'string' ? transcript : transcript.text || '';
        if ($('#record-caption')) $('#record-caption').textContent = 'Got it — edit your question or ask your teacher';
      } catch (error) {
        if ($('#record-caption')) $('#record-caption').textContent = 'Could not transcribe. Please try again or type your question.';
        showToast(`Transcription failed: ${getErrorMessage(error)}`, true);
      }
    });
    state.mediaRecorder.start();
    state.recording = true;
    $('#record-button').classList.add('recording');
    $('#record-caption').textContent = 'Listening… tap again to finish';
  } catch (error) {
    showToast(`Microphone access failed: ${getErrorMessage(error)}`, true);
  }
}

async function recordSession(feature, topic) {
  const entry = {
    feature,
    topic: String(topic || feature).slice(0, 120),
    timestamp: new Date().toISOString()
  };
  state.data.sessions.unshift(entry);
  state.data.sessions = state.data.sessions.slice(0, 100);
  if (entry.topic && !state.data.subjects.some((subject) => subject.toLowerCase() === entry.topic.toLowerCase())) {
    state.data.subjects.unshift(entry.topic);
    state.data.subjects = state.data.subjects.slice(0, 50);
  }
  await saveData();
}

async function recordMock(subject, scores) {
  state.data.mocks.unshift({ subject, scores: scores.slice(0, 500), timestamp: new Date().toISOString() });
  state.data.mocks = state.data.mocks.slice(0, 30);
  await saveData();
}

async function saveData() {
  await puter.kv.set(STORAGE_KEY, state.data);
}

async function loadData() {
  const saved = await puter.kv.get(STORAGE_KEY);
  if (saved && typeof saved === 'object') {
    state.data = {
      sessions: Array.isArray(saved.sessions) ? saved.sessions : [],
      mocks: Array.isArray(saved.mocks) ? saved.mocks : [],
      subjects: Array.isArray(saved.subjects) ? saved.subjects : []
    };
  }
}

function refreshProgress() {
  const count = state.data.sessions.length;
  const uniqueTopics = new Set(state.data.sessions.map((session) => session.topic.toLowerCase())).size;
  const dateKey = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  const sessionDays = new Set(state.data.sessions.map((session) => dateKey(new Date(session.timestamp))));
  const today = new Date();
  const todayKey = dateKey(today);
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  let streak = 0;
  if (sessionDays.has(todayKey) || sessionDays.has(dateKey(yesterday))) {
    const cursor = new Date(sessionDays.has(todayKey) ? today : yesterday);
    while (sessionDays.has(dateKey(cursor))) {
      streak += 1;
      cursor.setDate(cursor.getDate() - 1);
    }
  }
  $('#sessions-count').textContent = count;
  $('#topics-count').textContent = uniqueTopics;
  $('#streak-count').textContent = streak;
  $('#progress-sessions').textContent = count;
  $('#progress-topics').textContent = uniqueTopics;
  $('#progress-mocks').textContent = state.data.mocks.length;
  $('#welcome-date').textContent = today.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' }).toUpperCase();
  const weekDays = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(today);
    date.setDate(today.getDate() - (6 - index));
    return date;
  });
  document.querySelectorAll('.week-strip span').forEach((item, index) => {
    const date = weekDays[index];
    item.lastChild.textContent = date.toLocaleDateString(undefined, { weekday: 'narrow' });
    item.classList.toggle('today', dateKey(date) === todayKey);
    item.classList.toggle('has-activity', sessionDays.has(dateKey(date)) && dateKey(date) !== todayKey);
  });
  const log = $('#learning-log');
  log.replaceChildren();
  if (!count) {
    const empty = document.createElement('p');
    empty.className = 'empty-log';
    empty.textContent = 'Your learning log will grow as you explore. Pick a study tool to begin.';
    log.append(empty);
    return;
  }
  state.data.sessions.slice(0, 8).forEach((session) => {
    const row = document.createElement('div');
    row.className = 'log-item';
    const description = document.createElement('div');
    const topic = document.createElement('strong');
    topic.textContent = session.topic;
    const date = document.createElement('span');
    date.textContent = new Date(session.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    const kind = document.createElement('span');
    kind.className = 'log-kind';
    kind.textContent = FEATURE_INFO[session.feature] ? FEATURE_INFO[session.feature].title.replace(/[.?!]/g, '') : session.feature;
    description.append(topic, date);
    row.append(description, kind);
    log.append(row);
  });
}

function setView(view) {
  document.querySelectorAll('.page-view').forEach((section) => { section.hidden = section.id !== `${view}-view`; });
  document.querySelectorAll('.nav-item[data-view]').forEach((item) => item.classList.toggle('active', item.dataset.view === view));
  $('#current-section').textContent = view === 'home' ? 'Home' : view === 'tools' ? 'Study tools' : 'My progress';
}

async function signIn() {
  const button = $('#sign-in-button');
  button.disabled = true;
  $('#auth-status').textContent = 'Opening secure Puter sign-up…';
  try {
    await puter.auth.signIn();
    await initializeUser();
  } catch (error) {
    $('#auth-status').textContent = getErrorMessage(error);
    showToast(`Sign-up or sign-in failed: ${getErrorMessage(error)}`, true);
  } finally {
    button.disabled = false;
  }
}

async function initializeUser() {
  state.user = await puter.auth.getUser();
  await loadData();
  const name = state.user && (state.user.username || state.user.name || state.user.email) || 'Student';
  $('#profile-name').textContent = name;
  $('#auth-screen').hidden = true;
  appShell.hidden = false;
  refreshProgress();
}

async function startApp() {
  if (typeof puter === 'undefined') {
    $('#auth-status').textContent = 'Puter could not load. Check your connection and refresh.';
    showToast('Could not connect to Puter.js. Check your internet connection.', true);
    return;
  }
  try {
    if (await puter.auth.isSignedIn()) await initializeUser();
    else $('#auth-status').textContent = 'Sign in or create your account to begin.';
  } catch (error) {
    $('#auth-status').textContent = `Could not connect your account: ${getErrorMessage(error)}`;
    showToast(`Puter sign-in check failed: ${getErrorMessage(error)}`, true);
  }
}

$('#sign-in-button').addEventListener('click', signIn);
$('#sign-out-button').addEventListener('click', async () => {
  try {
    await puter.auth.signOut();
    state.user = null;
    appShell.hidden = true;
    authScreen.hidden = false;
    $('#auth-status').textContent = 'You are signed out. Sign in again whenever you’re ready.';
  } catch (error) {
    showToast(`Sign-out failed: ${getErrorMessage(error)}`, true);
  }
});
document.addEventListener('click', (event) => {
  const viewButton = event.target.closest('[data-view]');
  if (viewButton) setView(viewButton.dataset.view);
  const featureButton = event.target.closest('[data-open-feature]');
  if (featureButton) openFeature(featureButton.dataset.openFeature);
});
$('#modal-close').addEventListener('click', closeFeature);
modal.addEventListener('click', (event) => { if (event.target === modal) closeFeature(); });
document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && !modal.hidden) closeFeature(); });
startApp();
